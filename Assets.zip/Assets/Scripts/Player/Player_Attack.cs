﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Player_Attack : MonoBehaviour
{
    bool _attackPressed = false;

    public GameObject attackRadius;

    private Attributes _myAttributes;

    public TextMeshProUGUI enemyNameUI;
    public Image enemyHealthImage;

    public GameObject attackingUI;

    private float _setUIActiveAtTime;
    private float _waitThisLongToTurnOffAttackingUI = 3.0f;

    public GameObject damageDisplay;


    // Start is called before the first frame update
    void Start()
    {
        attackingUI.SetActive(false);
        _myAttributes = GetComponent<Attributes>();
        attackRadius.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        DetectAttack();

        if(_attackPressed)
        {
            attackRadius.SetActive(true);
            DealDamage();
        }
        else
        {
            attackRadius.SetActive(false);
        }
        TurnOffAttackingUI();
       
    }

    void TurnOffAttackingUI()
    {
        if(_setUIActiveAtTime + _waitThisLongToTurnOffAttackingUI < Time.timeSinceLevelLoad)
        {
            attackingUI.SetActive(false);
        }
    }

    void DealDamage()
    {
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");

        float minDistance = 0.64f;

        foreach (GameObject enemy in enemies)
        {
            if (Vector2.Distance(attackRadius.transform.position, enemy.transform.position) < minDistance)
            {
                if(attackingUI.activeSelf == false)
                {
                    attackingUI.SetActive(true);
                }

                if (enemy.GetComponent<Attributes>().IsAlive())
                {
                    _setUIActiveAtTime = Time.timeSinceLevelLoad;

                    Attributes thisEnemy = enemy.GetComponent<Attributes>();
                    enemy.GetComponent<Health>().DamageHealth(_myAttributes.GetStrength());

                    GameObject damageSpawn = Instantiate(damageDisplay, enemy.transform.position, Quaternion.identity);
                    damageSpawn.GetComponent<DamageText>().damageAmount = _myAttributes.GetStrength() - enemy.GetComponent<Attributes>().GetDefense();

                    enemyNameUI.text = thisEnemy.GetName();

                    if (thisEnemy.GetHealth() != 0)
                    {
                        enemyHealthImage.fillAmount = (float)thisEnemy.GetHealth() / (float)thisEnemy.GetMaxHealth();
                    }
                    else
                    {
                        enemyHealthImage.fillAmount = 0;
                    }
                } // end if enemy alive

            }
        }
    }


    void DetectAttack()
    {
        if(InputManager.ActionButtonDown())
        {
            _attackPressed = true;
        }
        else
        {
            _attackPressed = false;
        }
    }
}
