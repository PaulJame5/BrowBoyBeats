﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Move : MonoBehaviour
{
    private float _speed = 5;

    private bool _pressedUp = false,_pressedDown = false,_pressedRight = false, _pressedLeft = false;

    private Transform _myTransform;

    Attributes _myAttributes;

    // Start is called before the first frame update
    void Start()
    {
        _myAttributes = GetComponent<Attributes>();
        _myTransform = transform;
        _speed = _myAttributes.GetSpeed();
    }

    // Update is called once per frame
    void Update()
    {
        DetectMovementInput();
        
    }

    private void FixedUpdate()
    {
        Move();
    }

    private void Move()
    {
        Vector3 pos = _myTransform.position;

        // Perform Actions Detected in update
        if (_pressedDown)
        {
            pos.y -= _speed * Time.fixedDeltaTime;
            _myTransform.position = pos;
        }
        else if (_pressedUp)
        {
            pos.y += _speed * Time.fixedDeltaTime;
            _myTransform.position = pos;
        }

        if (_pressedRight)
        {
            _myTransform.localScale = new Vector3(1, 1, 1);
            pos.x += _speed * Time.fixedDeltaTime;
            _myTransform.position = pos;
        }
        else if (_pressedLeft)
        {
            _myTransform.localScale = new Vector3(-1, 1, 1);
            pos.x -= _speed * Time.fixedDeltaTime;
            _myTransform.position = pos;
        }
    }

    private void DetectMovementInput()
    {
        // Detect Input
        if (InputManager.LeftButton())
        {
            _pressedLeft = true;
            _pressedRight = false;
        }
        else if (InputManager.RightButton())
        {
            _pressedRight = true;
            _pressedLeft = false;
        }
        else
        {
            _pressedRight = false;
            _pressedLeft = false;
        }

        if (InputManager.UpButton())
        {
            _pressedUp = true;
            _pressedDown = false;
        }
        else if (InputManager.DownButton())
        {
            _pressedDown = true;
            _pressedUp = false;
        }
        else
        {
            _pressedUp = false;
            _pressedDown = false;
        }
    }
}
