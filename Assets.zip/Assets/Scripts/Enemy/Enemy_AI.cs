﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_AI : MonoBehaviour
{
    [SerializeField]
    public const int HIVE_MIND_ID = 0;
    public static bool[] s_memberOfGroupAttacking = new bool[5];

    bool _attackMode = false;

    float _timeInbetweenAttacking = 1.8f;
    float _timeSinceLastAttack;

    Transform _myTransform;

    Vector2 _offset = new Vector2(2.4f, 3);

    bool _targetPlayerSet = false;
    GameObject[] _players;
    int _playerIndexTargetChoice = 0;


    Attributes _myAttributes;
    

    public static List<string> names = new List<string>{ "Lou", "John", "Peter", "Pete","Bob","Brow", "Paul","David","Alan","Jack","Curly","Broly","Goku","Wok","Jim","Alex","Mikel","Noel","Ross","Dara","Phil","Lei" };


    public enum Target
    {
        LEFT,
        RIGHT,
        TOP,
        BOTTOM,
        TOP_LEFT,
        TOP_RIGHT,
        BOTTOM_LEFT,
        BOTTOM_RIGHT,
        WAIT
    }

    public Target currentTarget;
    
    // Start is called before the first frame update
    void Start()
    {

        _myAttributes = GetComponent<Attributes>();

        int nameChoice = Random.Range(0, names.Count);

        _myAttributes.SetName(names[nameChoice]);

        names.RemoveAt(nameChoice);

        _attackMode = false;
        _players = GameObject.FindGameObjectsWithTag("Player");
        _myTransform = transform;
    }

    // Update is called once per frame
    void Update()
    {
        if(!_attackMode)
        {
            if(s_memberOfGroupAttacking[HIVE_MIND_ID] == false)
            {
                s_memberOfGroupAttacking[HIVE_MIND_ID] = true;
                SelectAttacker();
            }
            else
            {
                Surround();
            }
        }
        else
        {
            if (_myAttributes.IsAlive())
            {
                Attack();
            }
            else
            {
                s_memberOfGroupAttacking[HIVE_MIND_ID] = false;
            }
        }
    }

    void Attack()
    {
        float distanceFromPlayer = Vector2.Distance(_myTransform.position, _players[_playerIndexTargetChoice].transform.position);

        if (distanceFromPlayer > .64f)
        {
            _myTransform.position = Vector3.MoveTowards(_myTransform.position, _players[_playerIndexTargetChoice].transform.position, _myAttributes.GetSpeed() * Time.deltaTime);
        }
        else
        {
            if(_timeInbetweenAttacking + _timeSinceLastAttack < Time.timeSinceLevelLoad)
            {
                _timeSinceLastAttack = Time.timeSinceLevelLoad;
            }
        }


    }


    void SelectAttacker()
    {
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");

        bool selectedAgreesor = false;


        while (!selectedAgreesor)
        {
            int pickedEnemy = Random.Range(0, enemies.Length);
            
            if (enemies[pickedEnemy].GetComponent<Attributes>().IsAlive() && enemies[pickedEnemy].GetComponent<Enemy_AI>().GetHiveMindID() == HIVE_MIND_ID)
            {
                foreach(GameObject enemy in enemies)
                {
                    if (enemy != this.gameObject)
                    {
                        if (enemy.GetComponent<Enemy_AI>().GetHiveMindID() == HIVE_MIND_ID)
                        {
                            enemy.GetComponent<Enemy_AI>().SetAttackMode(false);
                        }
                    }
                }

                enemies[pickedEnemy].GetComponent<Enemy_AI>().SetAttackMode(true);
                selectedAgreesor = true;
            }
        }
    }

    void SetAttackMode(bool t_set)
    {
        _attackMode = t_set;
    }

    void Surround()
    {
        if (_timeInbetweenAttacking + _timeSinceLastAttack < Time.timeSinceLevelLoad && GetComponent<Attributes>().IsAlive())
        {
            Vector3 target = _players[_playerIndexTargetChoice].transform.position;


            switch (currentTarget)
            {

                case Target.BOTTOM:
                    target.y -= _offset.y;
                    break;

                case Target.TOP:
                    target.y += _offset.y;
                    break;

                case Target.LEFT:
                    target.x -= _offset.x;
                    break;

                case Target.RIGHT:
                    target.x += _offset.x;
                    break;

                case Target.TOP_LEFT:
                    target.y += _offset.y;
                    target.x -= _offset.x;
                    break;

                case Target.TOP_RIGHT:
                    target.x += _offset.x;
                    target.y += _offset.y;
                    break;

                case Target.BOTTOM_LEFT:
                    target.y -= _offset.y;
                    target.x -= _offset.x;
                    break;

                case Target.BOTTOM_RIGHT:
                    target.x += _offset.x;
                    target.y -= _offset.y;
                    break;

                case Target.WAIT:
                    target = _myTransform.position;
                    break;
                default:
                    currentTarget = Target.WAIT;
                    break;
            }


            _myTransform.position = Vector3.MoveTowards(_myTransform.position, target, _myAttributes.GetSpeed() * Time.deltaTime);

            float distanceFromTarget = Vector2.Distance(_myTransform.position, target);

            if (distanceFromTarget < 0.5f)
            {
                int newTarget = Random.Range(0, 8);
                currentTarget = (Target)newTarget;
                _timeSinceLastAttack = Time.timeSinceLevelLoad;
            }

        } // end of time since attack
    } // End SUrround()

    void ChoosePlayerTarget()
    {
        _playerIndexTargetChoice = Random.Range(0, _players.Length) - 1;
    }

    int GetHiveMindID()
    {
        return HIVE_MIND_ID;
    }
    
}
