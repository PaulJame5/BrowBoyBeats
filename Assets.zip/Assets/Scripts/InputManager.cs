﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputManager : MonoBehaviour
{
  
    public static bool ActionButtonDown()
    {

        return Input.GetKeyDown(KeyCode.Space);
    }

    public static bool ActionButton()
    {
        return Input.GetKey(KeyCode.Space);
    }

    public static bool BackButton()
    {
        return Input.GetKey(KeyCode.Escape);
    }

    public static bool BackButonDown()
    {
        return Input.GetKeyDown(KeyCode.Escape);
    }

    /// <summary>
    /// Returns true if right button held
    /// </summary>
    /// <returns></returns>
    public static bool RightButton()
    {
        return Input.GetKey(KeyCode.RightArrow);
    }

    /// <summary>
    /// Returns true if right button pressed
    /// </summary>
    /// <returns></returns>
    public static bool RightButtonDown()
    {
        return Input.GetKeyDown(KeyCode.RightArrow);
    }

    /// <summary>
    /// Returns true if left button held
    /// </summary>
    /// <returns></returns>
    public static bool LeftButton()
    {
        return Input.GetKey(KeyCode.LeftArrow);
    }

    /// <summary>
    /// Returns true if left button pressed
    /// </summary>
    /// <returns></returns>
    public static bool LeftButtonDown()
    {
        return Input.GetKeyDown(KeyCode.LeftArrow);
    }

    /// <summary>
    /// Returns true if up button held
    /// </summary>
    /// <returns></returns>
    public static bool UpButton()
    {
        return Input.GetKey(KeyCode.UpArrow);
    }

    /// <summary>
    /// Returns true if up button pressed
    /// </summary>
    /// <returns></returns>
    public static bool UpButtonDown()
    {
        return Input.GetKeyDown(KeyCode.UpArrow);
    }

    /// <summary>
    /// Returns true if down button held
    /// </summary>
    /// <returns></returns>
    public static bool DownButton()
    {
        return Input.GetKey(KeyCode.DownArrow);
    }

    /// <summary>
    /// Returns true if down button pressed
    /// </summary>
    /// <returns></returns>
    public static bool DownButtonDown()
    {
        return Input.GetKeyDown(KeyCode.DownArrow);
    }










}
