﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageText : MonoBehaviour
{
    public int damageAmount;
    bool setDamageText = false;

    float _spawnedAt;
    static float _wait = 0.5f;
    static float _speed = 5;

    // Start is called before the first frame update
    void Start()
    {
        setDamageText = false;
        _spawnedAt = Time.timeSinceLevelLoad;
    }

    // Update is called once per frame
    void Update()
    {
        if (_spawnedAt + _wait > Time.timeSinceLevelLoad)
        {
            if (!setDamageText)
            {
                transform.GetChild(0).GetComponent<TMPro.TextMeshProUGUI>().text = damageAmount.ToString();
                _spawnedAt = Time.timeSinceLevelLoad;
                setDamageText = true;
            }
            else
            {
                transform.position += new Vector3(0, Time.deltaTime * _speed, 0);
            }
        }
        else
        {
            Destroy(gameObject);
        }
    }
}
