﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Health : MonoBehaviour
{
    public int _health;

    private Attributes _myAttributes;
    

    // Start is called before the first frame update
    void Start()
    {
        _myAttributes = GetComponent<Attributes>();
        _health = _myAttributes.GetMaxHealth();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void DamageHealth(int t_amount)
    {
        int damageToDeal = t_amount - _myAttributes.GetDefense();

        if(damageToDeal > 0)
        {
            _health -= damageToDeal;
        }

        if(_health < 0)
        {
            _health = 0;
        }

        if(_myAttributes.IsAlive() && _health == 0)
        {
            _myAttributes.SetAlive(false);
            StartCoroutine(FlashDead());
        }

        _myAttributes.SetHealth(_health);
    }


    // Functions to be used as Coroutines MUST return an IEnumerator
    IEnumerator FlashDead()
    {
        for (int i = 0; i < 5; i++)
        {
            Color col = GetComponent<SpriteRenderer>().color;
            col.a = 0;
            GetComponent<SpriteRenderer>().color = col;
            yield return new WaitForSeconds(.1f);
            col.a = 1;
            GetComponent<SpriteRenderer>().color = col;
            yield return new WaitForSeconds(.1f);

            if(i == 4)
            {
                Enemy_AI.names.Add(_myAttributes.GetName());
                this.gameObject.SetActive(false);
            }
        }
    }



}
