﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Attributes : MonoBehaviour
{
    [SerializeField]
    Stats _myStats;

    [SerializeField]
    State _myState;



    public bool IsAlive()
    {
        return _myState.alive;
    }

    public void SetAlive(bool t_bool)
    {
        _myState.alive = t_bool;
    }

    public float GetSpeed()
    {
        return _myStats.speed;
    }

    public int GetHealth()
    {
        return _myStats.health;
    }

    public int GetMaxHealth()
    {
        return _myStats.maxHealth;
    }

    public void SetHealth(int t_amount)
    {
        _myStats.health = t_amount;
    }

    public int GetDefense()
    {
        return _myStats.defense;
    }

    public int GetStrength()
    {
        return _myStats.strength;
    }

    public void IncreaseSpeed(float t_amount)
    {
        _myStats.speed += t_amount;
    }

    public void IncreaseHealth(int t_amount)
    {
        _myStats.health += t_amount;
    }

    public void IncreaseMaxHealth(int t_amount)
    {
        _myStats.maxHealth += t_amount;
    }

    public void IncreaseDefense(int t_amount)
    {
        _myStats.defense += t_amount;
    }

    public void IncreaseStrength(int t_amount)
    {
        _myStats.strength += t_amount;
    }

    public string GetName()
    {
        return _myStats.name;
    }

    public void SetName(string t_name)
    {
        _myStats.name = t_name;
    }


}
