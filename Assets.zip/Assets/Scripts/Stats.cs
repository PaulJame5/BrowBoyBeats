﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;


[Serializable]
class Stats
{
    public int health = 100;
    public int maxHealth = 100;
    public int strength;
    public int defense;
    public float speed;
    public string name;
}




