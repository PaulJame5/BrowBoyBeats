﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[Serializable]
public class State
{
    public bool alive = true;
    public bool invincible = false;
    public bool flashingSprite = false;

}
